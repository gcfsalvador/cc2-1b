##Gian Cyrus F. Salvador
#CITCS-1B-CC2

#number pattern using a loop

rows = 5
for i in range(1, rows + 1):
    for j in range(1, i + 1):
        print(j, end=' ')
    print("")

print("=========")
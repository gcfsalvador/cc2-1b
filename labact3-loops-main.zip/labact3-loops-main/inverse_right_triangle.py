##Gian Cyrus F. Salvador
#CITCS-1B-CC2
#inverse_right_triangle

rows = 5
for i in range(rows, 1, -1):
    for j in range(1, i + 1):
        print(j, end=' ')
    print("")
print("1")

print("=========")
##Gian Cyrus F. Salvador
#CITCS-1B-CC2
#following number pattern using a loop

size = 10
sum=0
for i in range(1, size + 1):
    sum +=i
print(sum)

print("=========")